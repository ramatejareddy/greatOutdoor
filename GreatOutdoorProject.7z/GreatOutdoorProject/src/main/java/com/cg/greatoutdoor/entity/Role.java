package com.cg.greatoutdoor.entity;

public enum Role {

}
