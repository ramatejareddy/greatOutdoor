package com.cg.greatoutdoor.dao;



import java.util.List;

import com.cg.greatoutdoor.entity.Cart;


public interface CartDaoInterface {

	

	boolean checkId(int userId, int productId);

	
	boolean create(Cart cart);

	Cart getProductInCart(int productId);

	List<Cart> retrieve(int userId);

	boolean deleteProduct(int userId, int productId);

}
