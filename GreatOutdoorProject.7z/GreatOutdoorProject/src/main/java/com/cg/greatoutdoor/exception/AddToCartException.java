package com.cg.greatoutdoor.exception;

public class AddToCartException extends Exception {
	private static final long serialVersionUID = 1L;	
	

	

	public AddToCartException(String message) {
		super(message);
	}

	
}
