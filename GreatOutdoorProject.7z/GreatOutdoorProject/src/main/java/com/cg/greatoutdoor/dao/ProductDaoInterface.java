package com.cg.greatoutdoor.dao;

import com.cg.greatoutdoor.entity.Product;

public interface ProductDaoInterface {

	Product findById(int productId);

}
