package com.cg.greatoutdoor.service;


import java.util.List;

import com.cg.greatoutdoor.dto.CartDetails;
import com.cg.greatoutdoor.entity.Cart;
import com.cg.greatoutdoor.exception.AddToCartException;
import com.cg.greatoutdoor.exception.ProductException;
import com.cg.greatoutdoor.exception.UserException;

public interface CartServiceInterface {

	public boolean checkId(int userId, int productId) throws ProductException, UserException, AddToCartException;

	public boolean addToCart(Cart cart) throws ProductException, AddToCartException, UserException;

	public boolean updateCartProduct(int productId,int quantity) throws AddToCartException, ProductException;

	public boolean removeProduct(int  userId, int  productId) throws ProductException, UserException;

	public List<CartDetails> retrive(int userId) throws ProductException, UserException;






}
