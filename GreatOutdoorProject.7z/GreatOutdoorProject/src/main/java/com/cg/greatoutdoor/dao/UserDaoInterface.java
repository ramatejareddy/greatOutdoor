package com.cg.greatoutdoor.dao;

import com.cg.greatoutdoor.entity.User;

public interface UserDaoInterface {

	User findById(int userId);

}
