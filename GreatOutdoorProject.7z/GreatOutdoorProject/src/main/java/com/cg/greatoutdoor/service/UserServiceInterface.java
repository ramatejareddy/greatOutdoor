package com.cg.greatoutdoor.service;

import com.cg.greatoutdoor.entity.User;
import com.cg.greatoutdoor.exception.UserException;

public interface UserServiceInterface {

	User findUserId(int userId) throws UserException;

}
