package com.cg.greatoutdoor.service;

import com.cg.greatoutdoor.entity.Product;
import com.cg.greatoutdoor.exception.ProductException;

public interface ProductServiceInterface {

	Product findProductId(int productId) throws ProductException;

}
